#include <iostream>

using namespace std;

int main()
{
    cout << "Hello Brain Mentors!" << endl;
    return 0;
}
