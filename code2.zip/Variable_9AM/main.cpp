#include <iostream>

using namespace std;

//Variable: vary / change
//It is a container that holds something.

int main()
{
    int a = 10; // declare/create and initialize/assign

    cout<<"a is:"<<a<<endl; // endl- new line

    a = 60; // re-initialization

    cout<<"a is:"<<a<<endl;

    return 0;
}
