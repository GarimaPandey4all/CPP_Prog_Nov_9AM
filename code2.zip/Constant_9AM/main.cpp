#include <iostream>

using namespace std;

//Constant: Fixed the value

int main()
{
    const int a = 10;

    cout<<"a is:"<<a<<endl;

    //a = 60; // error

    return 0;
}
