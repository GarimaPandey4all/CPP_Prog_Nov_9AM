#include <iostream>

using namespace std;

int main()
{
    int a = 10;

    a += 30; //a = a + 30;

    cout<<"a is:"<<a<<endl;

    a /= 50; //a = a / 50;

    cout<<"a is:"<<a<<endl;

    return 0;
}
