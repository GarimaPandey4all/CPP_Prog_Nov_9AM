#include <iostream>

using namespace std;

int main()
{
    int a = 10;
    char b = 'F';
    float c = 45.67f;
    double d = 67.890;
    string name = "Brain";

    cout<<"a is:"<<a<<endl;
    cout<<"b is:"<<b<<endl;
    cout<<"c is:"<<c<<endl;
    cout<<"d is:"<<d<<endl;
    cout<<"name is:"<<name<<endl;

    //SizeOF Operator
    cout<<"size of a is:"<<sizeof(a)<<endl;
    cout<<"size of b is:"<<sizeof(b)<<endl;
    cout<<"size of c is:"<<sizeof(c)<<endl;
    cout<<"size of d is:"<<sizeof(double)<<endl;
    cout<<"size of name is:"<<sizeof(string)<<endl;


    return 0;
}
