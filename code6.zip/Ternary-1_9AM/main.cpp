#include <iostream>

using namespace std;

/*
    Ternary Operator/Conditional Operator: Shorthand of If - else or If -else if - else

    Ternary: 3

    (Condition) ? True : False;
    (Expression-1) ? (Expression-2) : (Expression-3)

*/

int main()
{
    int a, b;

    cout<<"Enter value for a and b:";
    cin>>a>>b;

    (a > b) ? cout<<"A is Greater" : cout<<"B is Greater";

    return 0;
}
