#include <iostream>

using namespace std;

int main()
{
    int n, remainder;

    cout<<"Enter any number:";
    cin>>n;

    remainder = n % 2;

    if(remainder == 0)
    {
        cout<<"Number is Even";
    }
    else
    {
        cout<<"Number is Odd";
    }

    return 0;
}
