#include <iostream>

using namespace std;

int main()
{
    int n, remainder;

    cout<<"Enter any number:";
    cin>>n;

    remainder = n % 2;

    (remainder == 0) ? cout<<"Number is Even" : cout<<"Number is Odd";

    return 0;
}
