#include <iostream>

using namespace std;

int main()
{
    char ch;

    cout<<"Enter any character:";
    cin>>ch;

    cout<<"Entered character's value is:"<<ch<<endl;

    return 0;
}
