#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    cout<<"Equal to is:"<<(a == b)<<endl;
    cout<<"Not Equal to is:"<<(a != b)<<endl;
    cout<<"Greater than is:"<<(a > b)<<endl;
    cout<<"Less than is:"<<(a < b)<<endl;
    cout<<"Greater than and equal to is:"<<(a >= b)<<endl;
    cout<<"Less than and equal to is:"<<(a <= b)<<endl;

    return 0;
}
